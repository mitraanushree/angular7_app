export const environment = {
  production: true,
  firebase: {
    apiKey: "AIzaSyBMOaRr0NirNOX-eh2ITJBHUpL3ow8Hr4w",
    authDomain: "splendid-ground-95214.firebaseapp.com",
    databaseURL: "https://splendid-ground-95214.firebaseio.com",
    projectId: "splendid-ground-95214",
    storageBucket: "",
    messagingSenderId: "429226112331"
  }
};
