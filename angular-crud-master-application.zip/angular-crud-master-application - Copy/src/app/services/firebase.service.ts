import { Injectable } from '@angular/core';
import { AngularFirestore } from '@angular/fire/firestore';

@Injectable({
  providedIn: 'root'
})
export class FirebaseService {
  allImages = [];    

  constructor(public db: AngularFirestore) { }
  
  /*getAvatars(){
      return this.db.collection('/avatar').valueChanges()
  }*/

  getAvatars() {
    return this.allImages = Imagesdelatils.slice(0);
  }

  getUser(userKey){
    return this.db.collection('users').doc(userKey).snapshotChanges();
  }

  updateUser(userKey, value){
    value.nameToSearch = value.name.toLowerCase();
    return this.db.collection('users').doc(userKey).set(value);
  }

  deleteUser(userKey){
    return this.db.collection('users').doc(userKey).delete();
  }

  getUsers(){
    return this.db.collection('users').snapshotChanges();
  }

  searchUsers(searchValue){
    return this.db.collection('users',ref => ref.where('nameToSearch', '>=', searchValue)
      .where('nameToSearch', '<=', searchValue + '\uf8ff'))
      .snapshotChanges()
  }

  searchUsersByAge(value){
    return this.db.collection('users',ref => ref.orderBy('age').startAt(value)).snapshotChanges();
  }


  createUser(value, avatar){
    return this.db.collection('users').add({
      name: value.name,
      nameToSearch: value.name.toLowerCase(),
      surname: value.surname,
      age: parseInt(value.age),
      avatar: avatar
    });
  }
}

const Imagesdelatils = [
  { "id": 1, "link":"assets/Images/image1.png" },
  { "id": 2, "link": "assets/Images/image2.png" },
  { "id": 3, "link": "assets/Images/image3.png" },
  { "id": 4, "link": "assets/Images/image4.png" },
  { "id": 5, "link": "assets/Images/image5.png" },
  { "id": 6, "link": "assets/Images/image6.png" },
  { "id": 7, "link": "assets/Images/image7.png" },
  { "id": 8, "link": "assets/Images/image8.png" },
  { "id": 9, "link": "assets/Images/image9.png" }
]
